#!/bin/sh
dotnet /home/stefano/gral/T3.2/Binaries/GRAL_2019_01/bin/Release/netcoreapp2.1/GRAL_2019_01.dll > out.log 2>&1

